/*! For license information please see 577.0647ef6e.js.LICENSE.txt */
"use strict";(self.webpackChunkscop_studio_file_viewer_bundle=self.webpackChunkscop_studio_file_viewer_bundle||[]).push([["577"],{56(e,r,t){t.r(r),t.d(r,{CodeMirrorEditor:()=>h,default:()=>u});var i=t(848),o=t(720),s=t(88),l=t(332),n=t(109),a=t(781),d=t(632);let c=(0,a.createStyles)(e=>{let{token:r,css:t}=e;return{editor:t`
    display: flex;
    flex-direction: column;
    flex: 1;
    min-height: 0;

    .cm-editor {
      /*
       * The editor has to be sized as a flex child rather than with height: 100%.
       * A percentage height only resolves against a parent with a definite height, and
       * when it does not resolve the editor grows to fit its content - which leaves
       * .cm-scroller with nothing to scroll inside, so a long file is simply clipped.
       * This is the same approach Studio uses for its own CodeMirror instances.
       */
      flex: 1;
      min-height: 0;
      font-size: 12px;
      border: 1px solid ${r.colorBorder};
      border-radius: ${r.borderRadius}px;
      /* Keeps the scroller's corners inside the rounded border. */
      overflow: hidden;
    }

    .cm-editor.cm-focused {
      border-color: ${r.colorPrimary};
      /* CodeMirror's own focus ring would sit outside the border we just drew. */
      outline: none;
    }

    .cm-scroller {
      font-family: ${r.fontFamilyCode??"monospace"};
      overflow: auto;
    }
  `}}),h=e=>{let{path:r,value:t,onChange:a,readOnly:h}=e,{styles:u,theme:f}=c(),p=(0,o.useMemo)(()=>(function(e){let r,t,i;if(void 0===e)return!1;let o=e.trim().replace("#","");if(/^[0-9a-f]{6}$/i.test(o))r=parseInt(o.slice(0,2),16),t=parseInt(o.slice(2,4),16),i=parseInt(o.slice(4,6),16);else if(/^[0-9a-f]{3}$/i.test(o))r=parseInt(o[0]+o[0],16),t=parseInt(o[1]+o[1],16),i=parseInt(o[2]+o[2],16);else{let o=/rgba?\(\s*(\d+)[,\s]+(\d+)[,\s]+(\d+)/i.exec(e);if(null===o)return!1;r=Number(o[1]),t=Number(o[2]),i=Number(o[3])}return .2126*r+.7152*t+.0722*i<128})(f.colorBgContainer),[f.colorBgContainer]),m=(0,o.useMemo)(()=>{let e=[l.Lz.lineWrapping],t=(0,d.a)(r);return null!==t&&e.push(t),e},[r]);return(0,i.jsx)(s.Ay,{basicSetup:{lineNumbers:!0,highlightActiveLine:!h,highlightActiveLineGutter:!h,foldGutter:!0,autocompletion:!1},className:u.editor,extensions:m,onChange:a,readOnly:h,theme:p?n.bM:"light",value:t})},u=h}}]);