
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.scop_studio_file_viewer_bundle = "/bundles/scopstudiofileviewer/studio/dd781fff7c015565193324c57e32da29/static/js/remoteEntry.js"

      
    