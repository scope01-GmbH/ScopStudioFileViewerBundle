
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.scop_studio_file_viewer_bundle = "/bundles/scopstudiofileviewer/studio/0b41fb39066c6696a049941175afd066/static/js/remoteEntry.js"

      
    