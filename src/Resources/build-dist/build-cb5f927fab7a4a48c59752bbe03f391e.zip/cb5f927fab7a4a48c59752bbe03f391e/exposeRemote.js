
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.scop_studio_file_viewer_bundle = "/bundles/scopstudiofileviewer/studio/cb5f927fab7a4a48c59752bbe03f391e/static/js/remoteEntry.js"

      
    