/*! For license information please see 577.bd2bc548.js.LICENSE.txt */
"use strict";(self.webpackChunkscop_studio_file_viewer_bundle=self.webpackChunkscop_studio_file_viewer_bundle||[]).push([["577"],{56(e,t,r){r.r(t),r.d(t,{CodeMirrorEditor:()=>h,default:()=>p});var i=r(848),l=r(798),n=r(88),s=r(332),o=r(109),u=r(781),a=r(632);let c=(0,u.createStyles)(e=>{let{token:t,css:r}=e;return{editor:r`
    height: 100%;

    .cm-editor {
      height: 100%;
      font-size: 12px;
    }

    .cm-scroller {
      font-family: ${t.fontFamilyCode??"monospace"};
      overflow: auto;
    }
  `}}),h=e=>{let{path:t,value:r,onChange:u,readOnly:h}=e,{styles:p,theme:d}=c(),f=(0,l.useMemo)(()=>(function(e){let t,r,i;if(void 0===e)return!1;let l=e.trim().replace("#","");if(/^[0-9a-f]{6}$/i.test(l))t=parseInt(l.slice(0,2),16),r=parseInt(l.slice(2,4),16),i=parseInt(l.slice(4,6),16);else if(/^[0-9a-f]{3}$/i.test(l))t=parseInt(l[0]+l[0],16),r=parseInt(l[1]+l[1],16),i=parseInt(l[2]+l[2],16);else{let l=/rgba?\(\s*(\d+)[,\s]+(\d+)[,\s]+(\d+)/i.exec(e);if(null===l)return!1;t=Number(l[1]),r=Number(l[2]),i=Number(l[3])}return .2126*t+.7152*r+.0722*i<128})(d.colorBgContainer),[d.colorBgContainer]),m=(0,l.useMemo)(()=>{let e=[s.Lz.lineWrapping],r=(0,a.a)(t);return null!==r&&e.push(r),e},[t]);return(0,i.jsx)(n.Ay,{basicSetup:{lineNumbers:!0,highlightActiveLine:!h,highlightActiveLineGutter:!h,foldGutter:!0,autocompletion:!1},className:p.editor,extensions:m,height:"100%",onChange:u,readOnly:h,theme:f?o.bM:"light",value:r})},p=h}}]);