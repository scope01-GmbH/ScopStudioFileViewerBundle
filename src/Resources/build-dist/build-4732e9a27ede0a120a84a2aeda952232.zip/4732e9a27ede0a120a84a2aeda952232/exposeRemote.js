
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.scop_studio_file_viewer_bundle = "/bundles/scopstudiofileviewer/studio/4732e9a27ede0a120a84a2aeda952232/static/js/remoteEntry.js"

      
    