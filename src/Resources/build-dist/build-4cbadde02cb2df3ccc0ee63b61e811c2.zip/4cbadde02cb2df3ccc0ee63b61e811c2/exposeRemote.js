
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.scop_studio_file_viewer_bundle = "/bundles/scopstudiofileviewer/studio/4cbadde02cb2df3ccc0ee63b61e811c2/static/js/remoteEntry.js"

      
    